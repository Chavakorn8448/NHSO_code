import os
import json
import torch
import numpy as np
import tensorflow as tf
import librosa
import pickle
from pyannote.audio import Pipeline
from tqdm import tqdm
import soundfile as sf
import warnings

"""
@Trav pip installnumpy<2
torch
tensorflow
librosa
pyannote.audio
tqdm
soundfile 
na ja
"""

warnings.filterwarnings("ignore", category=UserWarning, module="pyannote.audio.models.blocks.pooling")
warnings.filterwarnings("ignore", category=UserWarning, module="librosa")
warnings.filterwarnings("ignore", category=RuntimeWarning, message="divide by zero encountered")
warnings.filterwarnings("ignore", category=UserWarning, message="No training configuration found")


TONE_CRITERIA = [
    'willing_to_serve',  # น้ำเสียงเต็มใจให้บริการ
    'not_sluggish',      # ไม่เนือย
    'not_monotone',      # ไม่ราบเรียบ
    'not_harsh',         # ไม่ห้วน ไม่แข็ง
]

# Model and resource paths
MODEL_DIR = "/home/ckancha/rnd/tone_analysis/Current/new_lstm/deployment" #TODO Change this a @Trav
DIARIZATION_MODEL = "pyannote/speaker-diarization-3.1"
HUGGINGFACE_TOKEN = "Change this please @Trav" #TODO

def load_resources(model_dir):
    """Load model, thresholds, and feature scalers"""
    # deficustom statistical pooling layer
    @tf.keras.utils.register_keras_serializable(package="ToneAnalysis")
    def statistical_pooling_layer(x):
        # mean
        mean_pool = tf.reduce_mean(x, axis=1)
        # standard
        std_pool = tf.math.reduce_std(x, axis=1)
        # max
        max_pool = tf.reduce_max(x, axis=1)
        
        # Concatenate along feature dimension
        return tf.concat([mean_pool, std_pool, max_pool], axis=1)
    
    model = tf.keras.models.load_model(
        os.path.join(model_dir, "multitask_full_model.h5"),
        custom_objects={"statistical_pooling_layer": statistical_pooling_layer}
    )
        
    with open(os.path.join(model_dir, "multitask_thresholds.json"), 'r') as f:
        thresholds = json.load(f)
    
    with open(os.path.join(model_dir, "feature_scalers.pkl"), 'rb') as f:
        scalers = pickle.load(f)
    
    return model, thresholds, scalers

def load_diarization_pipeline():
    """Load PyAnnote diarization pipeline"""
    return Pipeline.from_pretrained(
        DIARIZATION_MODEL,
        use_auth_token=HUGGINGFACE_TOKEN
    )

def extract_sequential_features(audio_file, sr=22050, frame_length=1024, hop_length=256, n_mfcc=13):
    """Extract sequential features from an audio file"""
    try:
        # Load audio file
        y, sr = librosa.load(audio_file, sr=sr)
        
        # Ensure minimum length
        if len(y) < sr * 0.5:  # At least 0.5 seconds
            y = np.pad(y, (0, sr - len(y)), 'constant')
        
        # Extract features
        features = {}
        
        # Pitch contour (F0) - Increased frame_length to avoid warnings
        f0, voiced_flag, voiced_probs = librosa.pyin(
            y, fmin=librosa.note_to_hz('C3'), fmax=librosa.note_to_hz('C7'),
            sr=sr, frame_length=frame_length, hop_length=hop_length
        )
        f0 = np.nan_to_num(f0)
        features['pitch_contour'] = f0
        features['voiced_flag'] = voiced_flag
        
        # Energy envelope
        energy = librosa.feature.rms(y=y, frame_length=frame_length, hop_length=hop_length)[0]
        features['energy_envelope'] = energy
        
        # MFCCs
        mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=n_mfcc, hop_length=hop_length)
        mfcc_delta = librosa.feature.delta(mfccs)
        mfcc_delta2 = librosa.feature.delta(mfccs, order=2)
        
        features['mfccs'] = mfccs
        features['mfcc_delta'] = mfcc_delta
        features['mfcc_delta2'] = mfcc_delta2
        
        # Spectral features
        spectral_centroid = librosa.feature.spectral_centroid(y=y, sr=sr, hop_length=hop_length)[0]
        spectral_bandwidth = librosa.feature.spectral_bandwidth(y=y, sr=sr, hop_length=hop_length)[0]
        spectral_flatness = librosa.feature.spectral_flatness(y=y, hop_length=hop_length)[0]
        
        features['spectral_centroid'] = spectral_centroid
        features['spectral_bandwidth'] = spectral_bandwidth
        features['spectral_flatness'] = spectral_flatness
        
        # Spectral flux
        spec = np.abs(librosa.stft(y, hop_length=hop_length))
        spectral_flux = np.zeros(spec.shape[1] - 1)
        for i in range(1, spec.shape[1]):
            spectral_flux[i-1] = np.sqrt(np.sum((spec[:, i] - spec[:, i-1])**2))
            
        features['spectral_flux'] = spectral_flux
        
        # Feature for willing_to_serve: pitch dynamics
        pitch_dynamics = np.gradient(f0)
        features['pitch_dynamics'] = pitch_dynamics
        
        # Feature for not_sluggish: onset strength
        onsets = librosa.onset.onset_strength(y=y, sr=sr, hop_length=hop_length)
        features['onset_strength'] = onsets
        
        # Feature for not_monotone: pitch variation
        if len(f0) > 1:
            f0_valid = f0[~np.isnan(f0)]
            if len(f0_valid) > 0:
                # Avoid division by zero
                std_f0 = np.std(f0_valid)
                if std_f0 > 0:
                    f0_scaled = (f0_valid - np.mean(f0_valid)) / std_f0
                else:
                    f0_scaled = np.zeros_like(f0_valid)
                pitch_range = np.max(f0_valid) - np.min(f0_valid) if len(f0_valid) > 0 else 0
                features['f0_scaled'] = f0_scaled
                features['pitch_range'] = np.full(len(f0), pitch_range)
        
        # Feature for not_harsh: spectral tilt
        stft = np.abs(librosa.stft(y, hop_length=hop_length))
        n_bins = stft.shape[0]
        low_freq = np.sum(stft[:n_bins//3, :], axis=0)
        high_freq = np.sum(stft[n_bins//3:, :], axis=0)
        # Avoid division by zero
        spectral_tilt = np.divide(high_freq, low_freq + 1e-10)
        
        features['spectral_tilt'] = spectral_tilt
        
        return features
    
    except Exception as e:
        print(f"Error extracting features: {str(e)}")
        return None

def normalize_features(features, scalers):
    """Normalize features using pre-trained scalers"""
    normalized_features = {}
    
    for key, feature in features.items():
        if key in scalers:
            try:
                # Reshape, normalize, and reshape back
                orig_shape = feature.shape
                flat_feature = feature.reshape(-1, 1)
                normalized = scalers[key].transform(flat_feature)
                normalized_features[key] = normalized.reshape(orig_shape)
            except Exception as e:
                print(f"Error normalizing feature {key}: {str(e)}")
                # Fall back to unnormalized feature
                normalized_features[key] = feature
        else:
            normalized_features[key] = feature
    
    return normalized_features

def pad_or_truncate_features(features, max_length=500):
    """Pad or truncate features to a fixed length"""
    padded_features = {}
    
    for key, feature in features.items():
        # Handle 1D and 2D features differently
        if feature.ndim == 1:
            current_length = len(feature)
            if current_length < max_length:
                padded = np.pad(feature, (0, max_length - current_length), 'constant')
            else:
                padded = feature[:max_length]
            padded_features[key] = padded
        elif feature.ndim == 2:
            current_length = feature.shape[1]
            if current_length < max_length:
                padded = np.pad(feature, ((0, 0), (0, max_length - current_length)), 'constant')
            else:
                padded = feature[:, :max_length]
            padded_features[key] = padded
    
    return padded_features

def prepare_features_for_model(features, feature_list):
    """Prepare features for model input"""
    # For 1D features
    features_1d = []
    for feature_name in feature_list:
        if feature_name in features:
            feature = features[feature_name]
            if feature.ndim == 1:
                features_1d.append(feature.reshape(1, -1))
            else:
                features_1d.append(feature)
    
    # Stack along feature dimension
    if features_1d:
        combined = np.vstack(features_1d)
        # Transpose to [time_steps, features]
        return combined.T
    else:
        return np.array([])

def extract_and_prepare_features(audio_file, feature_list, scalers):
    """Extract and prepare features for model input"""
    features = extract_sequential_features(audio_file)
    if features is None:
        return None
    
    normalized_features = normalize_features(features, scalers)

    padded_features = pad_or_truncate_features(normalized_features)
    
    model_input = prepare_features_for_model(padded_features, feature_list)
    
    model_input = np.expand_dims(model_input, axis=0)
    
    return model_input

def analyze_audio_file(audio_file, diarization_pipeline, model, thresholds, scalers, feature_list):
    """Analyze an audio file with speaker diarization and tone analysis"""
    print("/n/n/nLoading audio file...")
    waveform, sample_rate = librosa.load(audio_file, sr=16000, mono=True)
    
    # waveform format -> pyannode format
    waveform_tensor = torch.from_numpy(waveform).unsqueeze(0)
    
    print("Running speaker diarization...")
    diarization = diarization_pipeline({"waveform": waveform_tensor, "sample_rate": sample_rate})
    

    results = {}
    
    # assume Speaker 1: Agent
    if not diarization.labels():
        print("No speakers detected.")
        return results
        
    speaker = diarization.labels()[0]
    print(f"Analyzing first speaker: {speaker}")
    
    speaker_snippets = []
    
    segments_for_speaker = [(segment, track, speaker_label) 
                           for segment, track, speaker_label in diarization.itertracks(yield_label=True)
                           if speaker_label == speaker]
    
    print(f"Processing {len(segments_for_speaker)} audio segments...")
    for segment, track, speaker_label in tqdm(segments_for_speaker):
        start_sample = int(segment.start * sample_rate)
        end_sample = int(segment.end * sample_rate)
        duration = segment.end - segment.start
        
        # skip segments that's too short
        if duration < 0.5:
            continue
        
        # extract audio segment
        segment_waveform = waveform[start_sample:end_sample]
        
        # tmp file to extract features
        temp_path = f"temp_segment_{speaker}_{start_sample}_{end_sample}.wav"
        sf.write(temp_path, segment_waveform, sample_rate, 'PCM_16')
        
        try:
            features = extract_and_prepare_features(temp_path, feature_list, scalers)
            if features is None:
                continue
            
            # model inference
            raw_predictions = model.predict(features, verbose=0)
            
            snippet_results = {}
        
            for criterion in TONE_CRITERIA:
                output_name = f'{criterion}_output'
                
                if output_name in raw_predictions:
                    score = float(raw_predictions[output_name][0][0])
                    
                    if criterion in thresholds:
                        threshold = thresholds[criterion]['threshold']
                        passes = score >= threshold
                    else:
                        threshold = 0.5
                        passes = score >= threshold
                    
                    snippet_results[criterion] = {
                        'score': score,
                        'threshold': threshold,
                        'passes': passes
                    }
            
            speaker_snippets.append({
                'start': segment.start,
                'end': segment.end,
                'duration': duration,
                'results': snippet_results
            })
                        
        finally:
            # clean up
            if os.path.exists(temp_path):
                os.remove(temp_path)
    
    if not speaker_snippets:
        print("No valid speech segments found for analysis.")
        return results
    
    # total duration of speaking
    total_duration = sum(s['duration'] for s in speaker_snippets)
    
    criteria_summaries = {}
    for criterion in TONE_CRITERIA:
        # Filter snippets that have this criterion
        criterion_snippets = [s for s in speaker_snippets if criterion in s['results']]
        if not criterion_snippets:
            continue
            
        # duration-weighted average score
        weighted_sum = sum(
            s['results'][criterion]['score'] * s['duration']
            for s in criterion_snippets
        )
        
        total_weight = sum(
            s['duration']
            for s in criterion_snippets
        )
        
        avg_score = weighted_sum / total_weight if total_weight > 0 else 0
        
        threshold = thresholds[criterion]['threshold'] if criterion in thresholds else 0.5
        
        # pass = average score >= threshold from training
        passes = avg_score >= threshold
        
        # pass rate = number of passing snippets / total snippets
        passing_snippets = sum(
            1 for s in criterion_snippets
            if s['results'][criterion]['passes']
        )
        total_snippets = len(criterion_snippets)
        pass_fraction = f"{passing_snippets}/{total_snippets}"
        
        # summary
        criteria_summaries[criterion] = {
            'avg_score': avg_score,
            'threshold': threshold,
            'pass_fraction': pass_fraction,
            'overall_passes': passes
        }
    
    results[speaker] = {
        'snippets': speaker_snippets,
        'summary': {
            'total_snippets': len(speaker_snippets),
            'total_duration': total_duration,
            'criteria_summaries': criteria_summaries
        }
    }
    return results

def print_results_table(results):
    """Print results in a table format"""
    if not results:
        print("No results to display.")
        return 0
    
    if not results or not list(results.keys()):
        print("No speakers analyzed.")
        return 0
    
    # first speaker
    speaker = list(results.keys())[0]
    speaker_data = results[speaker]
    
    if 'summary' not in speaker_data:
        print("No summary data available.")
        return 0
        
    summary = speaker_data['summary']
    
    if 'criteria_summaries' not in summary or not summary['criteria_summaries']:
        print("No criteria summaries available.")
        return 0
    
    print("\n| Criterion | Average Score | Pass Rate | Result |")
    print("|-----------|---------------|-----------|--------|")
    
    passing_criteria = 0
    total_criteria = 0
    
    # print each criterion
    for criterion in TONE_CRITERIA:
        if criterion in summary['criteria_summaries']:
            crit_summary = summary['criteria_summaries'][criterion]
            avg_score = crit_summary['avg_score']
            pass_fraction = crit_summary['pass_fraction']
            passes = crit_summary['overall_passes']
            
            result = "PASS" if passes else "FAIL"
            
            print(f"| {criterion} | {avg_score:.2f} | {pass_fraction} | {result} |")
            
            if passes:
                passing_criteria += 1
            total_criteria += 1
    
    # print overall result
    final_pass = passing_criteria >= 3  # Pass if at least 3 criteria pass
    print(f"\nOverall: {passing_criteria}/{total_criteria} criteria passed - {'PASS' if final_pass else 'FAIL'}")
    
    return 1 if final_pass else 0

# optional
def save_results(results, output_path):
    """Save analysis results to a JSON file"""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # numpy -> python type (JSON)
    def convert_to_serializable(obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: convert_to_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [convert_to_serializable(item) for item in obj]
        else:
            return obj
    
    serializable_results = convert_to_serializable(results)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(serializable_results, f, ensure_ascii=False, indent=2)
    
    print(f"Results saved to {output_path}")

def criteria_1_5_tone(audio_file, output_dir=None):
    """Main function to run the tone analysis pipeline"""
    if output_dir is None:
        output_dir = os.getcwd()
    
    os.makedirs(output_dir, exist_ok=True)
    
    print("Loading model, threshodls, and scalers...")
    model, thresholds, scalers = load_resources(MODEL_DIR)
    diarization_pipeline = load_diarization_pipeline()
    
    feature_list = [
        'pitch_contour', 'energy_envelope', 'mfccs',
        'spectral_centroid', 'spectral_bandwidth', 'spectral_flatness',
        'spectral_flux', 'pitch_dynamics', 'onset_strength',
        'spectral_tilt'
    ]
    
    results = analyze_audio_file(
        audio_file, diarization_pipeline, model, thresholds, scalers, feature_list
    )
    
    detailed_results_path = os.path.join(output_dir, f"tone_analysis_results.json")
    save_results(results, detailed_results_path)
    
    return_code = print_results_table(results)
    
    print(f"Analysis complete for {audio_file}")
    
    return return_code


print(criteria_1_5_tone("/home/ckancha/rnd/tone_analysis/Current/new_lstm/deployment/z013_mic_actor061_impro5_2.flac"), "./")